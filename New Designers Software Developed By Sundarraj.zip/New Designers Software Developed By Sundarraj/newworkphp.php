							<?php	
								if(isset($_POST['wsubmit']))
									{
									
											$runs="INSERT INTO worklist(WORKNAME,SITEADDRESS,CUSTOMERNAME,CONTACTNO,WORKREFER,PROJECTTOTALAMOUNT) VALUES('{$_POST['wname']}','{$_POST['siteads']}','{$_POST['pownname']}','{$_POST['cno']}','{$_POST['wrefer']}','{$_POST['amount']}')";
											
											if($conf->query($runs))
											{
												echo "<script>window.open('New_Work.php?mes=Details Saved','_self');</script>";
											}
											else
											{
												echo "<script>window.open('New_Work.php?mes2=Details Not Saved','_self');</script>";
											}
										
									}
							?>