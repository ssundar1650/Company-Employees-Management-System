<?php
	include "conf.php";
	session_start();
	
	if(!isset($_SESSION['AID']))
	{
		echo "<script>window.open('index.php?mes=Please Login First','_self');</script>";
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Welcome To New Designers | Powered By : MSSoft1650</title>
	<link rel="stylesheet" href="mycss/style.css" />
	<link rel="stylesheet" href="mycss/style2.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link rel="stylesheet" href="mycss/loading.css" />
	<script src="js/jquery.js"></script>
	<script src="js/loading.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
	<style>
		.pagenum{
			padding:5px;
			margin-top:5px;
		}
		
	</style>
</head>
<body>
<div id="preloader">
	<div id="status">
	</div>
</div>
<div class="mainDivs">
	<div class="row">
		<div class="col-md-12">
			<?php include "Header.php"; ?>
		</div>
		<div class="col-md-3">
			<?php include "Sidemenu.php"; ?>
		</div>
		<div class="col-md-9">
			<div class="row">
				<div class="col-md-12">
					<div class="mainDiv">
						<div class="">
							<br>
							<h2 class="titletext text-center"><span>Total</span> Employees & Salary Details</h2>	
						</div>
											<?php
												$tsalary="SELECT COUNT( * ) AS TOTAL FROM totaldetails";
												$tol=$conf->query($tsalary);
												$rw=mysqli_fetch_assoc($tol);
												$tolsalary=$rw['TOTAL']; 
											?>
							<div class="table-responsive"><br>
							<table class="table tbe">
								<tr>
									<th class='theader'>S.No</th>
									<th class='theader'>Employee Name</th>
									<th class='theader'>Worked Date</th>
									<th class='theader'>Work Hour</th>
									<th class='theader'>Total Salary</th>
									
								</tr>
								<?php
									if(isset($_GET['page']))
									{
										$page=$_GET['page'];
									}
									else
									{
										$page=1;
									}
									if($page =="" || $page==1)
									{
										$page1=0;
									}
									else
									{
										$page1=($page*5)-5;
									}
									$run="SELECT * FROM totaldetails LIMIT $page1,5";
									$tot=$conf->query($run);

									if($tot->num_rows>0)
									{
										$i=0;
										while($row=$tot->fetch_assoc())
										{
											$i++;
											echo "
											
												<tr>
													<td class='ttitle'>$tolsalary</td>
													<td class='ttitle'>{$row['NAME']}</td>
													<td class='ttitle'>{$row['DATE']}</td>
													<td class='ttitle'>{$row['WORKINGHOUR']}</td>
													<td class='ttitle'>{$row['SALARY']}</td>
												
												</tr>
												
											";
											
										}
										
									}
									$run="SELECT * FROM totaldetails";
									$tot=$conf->query($run);
									$records = $tot->num_rows;
									$records_pages = $records/5;
									$records_pages= ceil($records_pages);
									
									
									if($records_pages >=2)
									{
										for($r=1;$r<=$records_pages;$r++)
										{
											echo '<a class="pagenum" href="?page='.$r.'">'.$r.'</a>';
										}
									}
									
								?>
							</table>
							</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-12">
			<?php include "Footer.php"; ?>
		</div>
	</div>
</div>
</body>
</html>