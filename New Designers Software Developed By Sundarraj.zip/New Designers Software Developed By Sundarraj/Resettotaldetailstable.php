
<?php
	if(isset($_POST['reset1']))
	{
		$setting="TRUNCATE TABLE totaldetails";
		
		if($conf->query($setting))
		{
			echo "<script>window.open('Dashboard.php?mes=Salary Details Table Reset','_self')</script>";
		}
		else
		{
			echo "Salary Table Not Reset";
		}
	}
?>
