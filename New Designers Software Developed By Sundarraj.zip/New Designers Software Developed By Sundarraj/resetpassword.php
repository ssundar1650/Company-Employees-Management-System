<?php
								if(isset($_POST['resetpass']))
								{
									$pass="SELECT * FROM admin WHERE APASSWORD='{$_POST['oldpass']}'";
								
									if($run=$conf->query($pass))
									{
										if($run->num_rows>0)
										{
											if($_POST['newpass1']==$_POST['newpass2'])
											{
												
												if($_POST['newpass2'])
												{
													$sql="UPDATE admin SET APASSWORD='{$_POST['newpass2']}' WHERE AID='{$_SESSION['AID']}'";
												
													if($conf->query($sql))
													{
														
														echo "<script>window.open('Settings.php?mess=Password Changed','_self')</script>";
													}
													else
													{
														echo "<script>window.open('Settings.php?mess=Password Not Changed','_self')</script>";
													}
												}
												else
												{
													echo "<p class='err'>Please Enter Password Six Character Or Above</p>";
												}
											}
											else
											{
												echo "<script>window.open('Settings.php?mess=Password Not Matched','_self')</script>";
											}
										}
										else
										{
											
										}
									}
									else{
										echo "<script>window.open('Settings.php?mess=Old Password Not Matched','_self')</script>";
									}
								}
							?>