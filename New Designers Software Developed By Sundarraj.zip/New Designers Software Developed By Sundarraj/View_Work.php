<?php
	include "conf.php";
	session_start();
	
	if(!isset($_SESSION['AID']))
	{
		echo "<script>window.open('index.php?mes=Please Login First','_self');</script>";
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Welcome To New Designers | Powered By : MSSoft1650</title>
	<link rel="stylesheet" href="mycss/style.css" />
	<link rel="stylesheet" href="mycss/style2.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link rel="stylesheet" href="mycss/loading.css" />
	<script src="js/jquery.js"></script>
	<script src="js/loading.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
	<style>
		.result{
			color:#F00000;
		}
		.vemp{
			margin:0px !important;
		}
		.tbe4{
			border:1px solid #1488CC;
			font-family: 'Poppins', sans-serif;
			margin-top:30px;
			color:#1488CC;
		}
	</style>
</head>
<body>
<div id="preloader">
	<div id="status">
	</div>
</div>
<div class="mainDivs">
	<div class="row">
		<div class="col-md-12">
			<?php include "Header.php"; ?>
		</div>
		<div class="col-md-3">
			<?php include "Sidemenu.php"; ?>
		</div>
		<div class="col-md-9">
			<div class="row">
				<div class="col-md-12">
					<div class="mainDiv">
						<?php
							$view="SELECT * FROM worklist WHERE ID={$_GET['id']}";
							
							$emp=$conf->query($view);
							
							if($emp->num_rows>0)
							{
								$row=$emp->fetch_assoc();
								
							}
							else
							{
								echo "<p class='error'>Data Not Found</p>";
							}
						?>
						
						<div class="">
							<br>
							<h2 class="titletext text-center"><span>Mr . <?php echo $row['CUSTOMERNAME']; ?></span> Work Details</h2>	
						</div>
						
						<div class="row">
							<div class="col-md-6">
							<div class="table-responsive">
								<table class="table tbe4">
									<!--<tr>
										<th class='theader'>Work Name : <?php echo $row['WORKNAME']; ?></th>
										<th class='theader'>Site Address : <?php echo $row['SITEADDRESS']; ?></th>
										<th class='theader'>Contact Number : <?php echo $row['CONTACTNO']; ?></th>
										<th class='theader'>Work Refer Name : <?php echo $row['WORKREFER']; ?></th>
										
									</tr>-->
									<tr>
										<td>
											<p class="vemp">Work Name : </p>
										<td>
										<td>
											<p class="vemp"><?php echo $row['WORKNAME']; ?></p>
										<td>
									</tr>
									<tr>
										<td>
											<p class="vemp">Site Address : </p>
										<td>
										<td>
											<p class="vemp"><?php echo $row['SITEADDRESS']; ?></p>
										<td>
									</tr>
									<tr>
										<td>
											<p class="vemp">Contact Number : </p>
										<td>
										<td>
											<p class="vemp"><?php echo $row['CONTACTNO']; ?></p>
										<td>
									</tr>
									<tr>
										<td>
											<p class="vemp">Work Refer Name : </p>
										<td>
										<td>
											<p class="vemp"><?php echo $row['WORKREFER']; ?></p>
										<td>
									</tr>
									<tr>
										<td>
											<p class="vemp">Project Amount : </p>
										<td>
										<td>
											<p class="vemp"><?php echo $row['PROJECTTOTALAMOUNT']; ?></p>
										<td>
									</tr>
									<tr>
										<td>
											<p class="vemp">Advance : </p>
											<?php
												
												
												$salary="SELECT SUM( ADVANCEAMOUNT ) AS TOTAL FROM workdetails WHERE PROJECTTOTALAMOUNT = '{$row['PROJECTTOTALAMOUNT']}'";
												$tol=$conf->query($salary);
												$rw=mysqli_fetch_assoc($tol);
												$Advanceamount=$rw['TOTAL']; 
											
											?>
										<td>
										<td>
											<p class="vemp"><?php echo "$Advanceamount" ?></p>
										<td>
									</tr>
									
									<tr>
										<td>
											<?php
												$ad=$Advanceamount;
												$prate=$row['PROJECTTOTALAMOUNT'];
												$t=$prate-$ad;
											?>
											<p class="vemp"><span class="vemp text-danger">Advance - Project Amount : </span></p>
											
										<td>
										<td>
											<p class="vemp text-danger"><?php echo $t; ?></p>
											
										<td>
									</tr>
									<!--<tr>
										<td>
											<p class="vemp">Total Salary : </p>
											<?php
												$salary="SELECT SUM( PACKETMONEY ) AS TOTAL FROM salary WHERE NAME = '{$row['NAME']}'";
												$tol=$conf->query($salary);
												$rw=mysqli_fetch_assoc($tol);
												$tolpmoney=$rw['TOTAL']; 
											?>
										<td>
										<td>
											<p class="vemp"><?php echo "<span class=''>$tolsalarys</span>" ?></p>
											
										<td>
									</tr>
									<tr>
										<td>
											<p class="vemp"><span class='result'>Packetmoney - Salary : </span></p>
										<td>
										<td>
												
											<p class="vemp">
												<?php
													$t=$tolsalarys-$tolpmoney;
													echo "<span class='result'>Rs : $t</span>";
												?>
											</p>
										<td>
									</tr>-->
									
								</table>
							</div>
							</div>
							<div class="col-md-6">
								<div class="photoDiv">
									<center><img src="img/newentry.png " /></center>
									<!--<div class="table-responsive">
							<table class="table tbe">
							<tr>
								<th class='theader'>S.No</th>
								<th class='theader'>Workname</th>
								<th class='theader'>Date</th>
								<th class='theader'>Projecttotalamount</th>
								<th class='theader'>Advanceamount</th>
								<th class='theader'>Balanceamount</th>
								
							</tr>
							<?php
							
							
								if(isset($_GET['page']))
								{
									$page=$_GET['page'];
								}
								else
								{
									$page=1;
								}
								if($page =="" || $page==1)
								{
									$page1=0;
								}
								else
								{
									$page1=($page*5)-5;
								}
								
								$run="SELECT * FROM workdetails WHERE CUSTOMERNAME = '{$row['CUSTOMERNAME']}'";
								$tot=$conf->query($run);
								$records = $tot->num_rows;
								$records_pages = $records/5;
								$records_pages= ceil($records_pages);
								
								
								if($records_pages >=2)
								{
									for($r=1;$r<=$records_pages;$r++)
									{
										echo '<a class="pagenum" href="?page='.$r.'">'.$r.'</a>';
									}
								}
								
								$run="SELECT * FROM workdetails WHERE CUSTOMERNAME = '{$row['CUSTOMERNAME']}' ORDER BY ID DESC LIMIT $page1,5";
								$tot=$conf->query($run);

								if($tot->num_rows>0)
								{
									$i=0;
									while($row=$tot->fetch_assoc())
									{
										$i++;
										echo "
										
											<tr>
												<td class='ttitle'>$i</td>
												<td class='ttitle'>{$row['WORKNAME']}</td>
												<td class='ttitle'>{$row['DATE']}</td>
												<td class='ttitle'>{$row["PROJECTTOTALAMOUNT"]}</td>
												<td class='ttitle'>{$row["ADVANCEAMOUNT"]}</td>
												<td class='ttitle'>{$row['BALANCEAMOUNT']}</td>
												
											</tr>
											
										";
										
									}
									
								}
								
								
								
							?>
						</table>
						</div>-->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-12">
			<?php include "Footer.php"; ?>
		</div>
	</div>
</div>
</body>
</html>