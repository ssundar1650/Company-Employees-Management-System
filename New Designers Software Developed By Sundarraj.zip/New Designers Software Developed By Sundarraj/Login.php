<?php
							if(isset($_POST["login"]))
							{
								$java="SELECT * FROM admin WHERE AEMAIL='{$_POST['uname']}' and APASSWORD='{$_POST['pass']}'";
								
								if($r=$conf->query($java))
								{
									if($r->num_rows>0)
									{
										$rt=$r->fetch_assoc();
										$_SESSION['AID']=$rt['AID'];
										$_SESSION['AEMAIL']=$rt['AEMAIL'];
										echo "<script>window.open('Dashboard.php','_self');</script>";
									}
									else
									{
										echo "<script>alert('Invalid Username Or Password :(');</script></p>";
									}
								}
								else
								{
									echo "";
								}
							}
						?>