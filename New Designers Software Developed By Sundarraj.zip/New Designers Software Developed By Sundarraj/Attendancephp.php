
<?php
if(isset($_POST['asubmit']))
	{
		$arun="INSERT INTO salary(NAME,ATTENDANCE,DATE,WORKINGHOUR,PACKETMONEY,SALARY) VALUE('{$_POST['ename']}','{$_POST['evalue']}','{$_POST['date']}','{$_POST['whour']}','{$_POST['pmoney']}','{$_POST['esalary']}')";
								
			if($conf->query($arun))
			{ 
				echo "<script>window.open('Attendance.php?mes=Details Saved','_self');</script>";
			}
			else
			{
				echo "Error";
			}
	}
?>