-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 02, 2018 at 01:20 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `newdesigners`
--
CREATE DATABASE IF NOT EXISTS `newdesigners` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `newdesigners`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `AID` int(100) NOT NULL AUTO_INCREMENT,
  `ANAME` varchar(100) NOT NULL,
  `AFATHERNAME` varchar(100) NOT NULL,
  `AEMAIL` varchar(100) NOT NULL,
  `APASSWORD` varchar(100) NOT NULL,
  `APINNUMBER` varchar(100) NOT NULL,
  PRIMARY KEY (`AID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`AID`, `ANAME`, `AFATHERNAME`, `AEMAIL`, `APASSWORD`, `APINNUMBER`) VALUES
(1, 'MSSoft1650', 'selvaraj', 'mssoft1650@gmail.com', '12345', '1650');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) NOT NULL,
  `FATHERNAME` varchar(100) NOT NULL,
  `PHONENUMBER` varchar(100) NOT NULL,
  `EMAIL` varchar(100) NOT NULL,
  `ADDRESS` varchar(100) NOT NULL,
  `DAYSALARY` varchar(100) NOT NULL,
  `PHOTO` longblob NOT NULL,
  `ATTENDANCE` int(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE IF NOT EXISTS `salary` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) NOT NULL,
  `ATTENDANCE` int(100) NOT NULL,
  `DATE` varchar(100) NOT NULL,
  `WORKINGHOUR` int(100) NOT NULL,
  `PACKETMONEY` int(100) NOT NULL,
  `SALARY` int(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`ID`, `NAME`, `ATTENDANCE`, `DATE`, `WORKINGHOUR`, `PACKETMONEY`, `SALARY`) VALUES
(3, 'Murukesan', 1, '01/10/2018', 8, 100, 500);

-- --------------------------------------------------------

--
-- Table structure for table `totaldetails`
--

CREATE TABLE IF NOT EXISTS `totaldetails` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(100) NOT NULL,
  `ATTENDANCE` int(100) NOT NULL,
  `DATE` varchar(100) NOT NULL,
  `WORKINGHOUR` int(100) NOT NULL,
  `PACKETMONEY` int(100) NOT NULL,
  `SALARY` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `workdetails`
--

CREATE TABLE IF NOT EXISTS `workdetails` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `CUSTOMER` varchar(100) NOT NULL,
  `WORKNAME` varchar(100) NOT NULL,
  `DATE` varchar(100) NOT NULL,
  `ADVANCEAMOUNT` varchar(100) NOT NULL,
  `BALANCEAMOUNT` varchar(100) NOT NULL,
  `PROJECTTOTALAMOUNT` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `workdetails`
--

INSERT INTO `workdetails` (`ID`, `CUSTOMER`, `WORKNAME`, `DATE`, `ADVANCEAMOUNT`, `BALANCEAMOUNT`, `PROJECTTOTALAMOUNT`) VALUES
(1, 'Ramu Arasatipatti', 'Sobaset', '28/09/2018', '1000', '40000', '50000'),
(2, 'S.Muthaiya', 'Window', '28/09/2018', '500', '25000', '30000'),
(3, 'S.Muthaiya', 'Window+Door', '29/09/2018', '1000', '30000', '40000'),
(4, 'S.Muthaiya', 'Window', '30/09/2018', '500', '29000', '30000');

-- --------------------------------------------------------

--
-- Table structure for table `worklist`
--

CREATE TABLE IF NOT EXISTS `worklist` (
  `ID` int(100) NOT NULL AUTO_INCREMENT,
  `WORKNAME` varchar(100) NOT NULL,
  `SITEADDRESS` varchar(100) NOT NULL,
  `CUSTOMERNAME` varchar(100) NOT NULL,
  `CONTACTNO` varchar(100) NOT NULL,
  `WORKREFER` varchar(100) NOT NULL,
  `PROJECTTOTALAMOUNT` int(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
