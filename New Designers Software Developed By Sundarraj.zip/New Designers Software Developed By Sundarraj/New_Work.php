<?php
	include "conf.php";
	session_start();
	
	if(!isset($_SESSION['AID']))
	{
		echo "<script>window.open('index.php?mes=Please Login First','_self');</script>";
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Welcome To New Designers | Powered By : MSSoft1650</title>
	<link rel="stylesheet" href="mycss/style.css" />
	<link rel="stylesheet" href="mycss/style2.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link rel="stylesheet" href="mycss/loading.css" />
	<script src="js/jquery.js"></script>
	<script src="js/loading.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
	<style>
	</style>
</head>
<body>
<div id="preloader">
	<div id="status">
	</div>
</div>
<div class="mainDivs">
	<div class="row">
		<div class="col-md-12">
			<?php include "Header.php"; ?>
		</div>
		<div class="col-md-3">
			<?php include "Sidemenu.php"; ?>
		</div>
		<div class="col-md-9">
			<div class="row">
				<div class="col-md-12">
					<div class="mainDiv">
					<br><br>
					<h2 class="titletext text-center"><span>New</span> Work</h2>
					<div class="row">
						<div class="col-md-6">
							<div class="iptDiv">
								<form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
									<input required type="text" name="wname" Placeholder="Enter Work Name : " class="eipt text-danger"/>
									<input required type="text" name="siteads" Placeholder="Site Address : " class="eipt"/>
									<input required type="text" name="pownname" Placeholder="Customer Name : " class="eipt"/>
									<input required type="text" name="cno" Placeholder="Contact No : " class="eipt"/>
									<input required type="text" name="wrefer" Placeholder="Work Refer : " class="eipt"/>
									<input required type="text" name="amount" Placeholder="Amount : " class="eipt"/>
									<input type="submit" name="wsubmit" value="Save" class="eipt btns btn-danger"/><input type="reset" name="reset" value="Reset" class="eipt btns btn-danger"/>
								</form>
								
								<?php 
									include "newworkphp.php";
								?>
								<?php
									if(isset($_GET['mes']))
									{
										echo "<p class='error text-center text-danger'>Details Saved</p>";
									}
									else if(isset($_GET['mes2']))
									{
										echo "<p class='error text-center text-danger'>Details Not Saved</p>";
									}
								?>
							</div>
						</div>
						
						<div class="col-md-6">
							<div class="iptDiv">
								<center><img src="img/addwor.png" class="" /></center>
							</div>
						</div>
					</div>
					</div>
					
				</div>
			</div>
		</div>
		<div class="col-md-12">
			<?php include "Footer.php"; ?>
		</div>
	</div>
</div>
</body>
</html>