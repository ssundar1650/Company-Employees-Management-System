
<?php
	if(isset($_POST['reset']))
	{
		$setting="TRUNCATE TABLE salary";
		
		if($conf->query($setting))
		{
			echo "<script>window.open('Dashboard.php?mes=Salary Table Reset','_self')</script>";
		}
		else
		{
			echo "Salary Not Table Reset";
		}
	}
?>
