<?php
	include "conf.php";
	session_start();
	
	if(!isset($_SESSION["AID"]))
	{
		echo "<script>window.open('index.php?mes=Please Login First','_self');</script>";
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Welcome To New Designers | Powered By : MSSoft1650</title>
	<link rel="stylesheet" href="mycss/style.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
	<link rel="stylesheet" href="mycss/loading.css" />
	<script src="js/jquery.js"></script>
	<script src="js/loading.js"></script>
</head>
<body>
<div id="preloader">
	<div id="status">
	</div>
</div>
<div class="mainDivs">
	<div class="row">
		<div class="col-md-12">
			<?php include "Header.php"; ?>
		</div>
		<div class="col-md-3">
			<?php include "Sidemenu.php"; ?>
		</div>
		<div class="col-md-9">
			<div class="row">
				<div class="col-md-12">
					<div class="mainDiv">
						<div class="titleDiv">
							<h1 class="titletext text-center"><span>Welcome</span> New Designers</h1>
							<p class="desctext text-center">New Designer's Interior Wood Working Company In Alangudi , Tamil Nadu India.</p>
							
						</div>
						<br>
						<p  class="desctext text-center">Contact No : 9629904769 Website : www.newdesignersalangudi.com</p>
						<div class="dtdiv">
							<br>
							<center><h5 class="desctext">Your Total Details</h5></center>
						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="divcom idiv">
									<center>
											<?php
												$tsalary="SELECT COUNT( ID ) AS TOTAL FROM employees";
												$tol=$conf->query($tsalary);
												$rw=mysqli_fetch_assoc($tol);
												$tolsalary=$rw['TOTAL']; 
											?>
										<img src="img/emp.png" class="iphoto" />
										<h4 class="ccolor">Total Employees</h4>
										<h3 class="ccolor1"><?php echo $tolsalary; ?></h3>
									</center>
								</div>
							</div>
							
							<div class="col-md-4">
								<div class="divcom idiv">
									<center>
											<?php
												$tsalary="SELECT COUNT( ID ) AS TOTAL FROM worklist";
												$tol=$conf->query($tsalary);
												$rw=mysqli_fetch_assoc($tol);
												$tolsalary=$rw['TOTAL']; 
											?>
										<img src="img/work.png" class="iphoto" />
										<h4 class="ccolor">Total Works</h4>
										<h3 class="ccolor1"><?php echo $tolsalary; ?></h3>
									</center>
								</div>
							</div>
							
							<div class="col-md-4">
								<div class="divcom idiv">
									<center>
											<?php
												$tsalary="SELECT SUM( SALARY ) AS TOTAL FROM totaldetails";
												$tol=$conf->query($tsalary);
												$rw=mysqli_fetch_assoc($tol);
												$tolsalary=$rw['TOTAL']; 
											?>
										<img src="img/salary.png" class="iphoto" />
										<h4 class="ccolor">Total Salary</h4>
										<h3 class="ccolor1"><?php echo $tolsalary; ?></h3>
									</center>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-12">
			<?php include "Footer.php"; ?>
		</div>
	</div>
</div>
</body>
</html>