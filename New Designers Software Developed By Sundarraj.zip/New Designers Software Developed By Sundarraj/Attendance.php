<?php
	include "conf.php";
	session_start();
	
	if(!isset($_SESSION['AID']))
	{
		echo "<script>window.open('index.php?mes=Please Login First','_self');</script>";
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Welcome To New Designers | Powered By : MSSoft1650</title>
	<link rel="stylesheet" href="mycss/style.css" />
	<link rel="stylesheet" href="mycss/style2.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
	<link rel="stylesheet" href="mycss/loading.css" />
	<script src="js/jquery.js"></script>
	<script src="js/loading.js"></script>
	<style>
		
	</style>
</head>
<body>
<div id="preloader">
	<div id="status">
	</div>
</div>
<div class="mainDivs">
	<div class="row">
		<div class="col-md-12">
			<?php include "Header.php"; ?>
		</div>
		<div class="col-md-3">
			<?php include "Sidemenu.php"; ?>
		</div>
		<div class="col-md-9">
			<div class="row">
				<div class="col-md-12">
					<div class="mainDiv">
						<div class="">
						
							<h2 class="titletext text-center"><span>Attendance</span> Details</h2>	
						</div>
						<div class="row">
							<div class="col-md-6">
							<br><br>
							<form action="<?php $_SERVER['PHP_SELF'];?>" method="POST">
							<div class="customselect">
								<select required name="ename" class="eipt" placeholder="">
									<option class="elist" style="">Select Employee Name</option>
									<?php
										$run="SELECT * FROM employees";
										$tot=$conf->query($run);
										
										if($tot->num_rows>0)
										{
											$i=0;
											while($row=$tot->fetch_assoc())
											{
												
												echo "
												
													<option  class='elist' Value='{$row['NAME']}'>
														{$row['NAME']}
													</option>
													
												";
												
											}
											
										}
									?>
								</select>
							</div>	
								<select required name="evalue" class="eipt">
									<option class='elist'>Select Value</option>
									<option class='elist' value="1">Working</option>
									<option class='elist' value="0">Leave</option>
								</select>
								
								<input type="text" required class="eipt" placeholder="Enter Date : " name="date" />
								<input type="text" required class="eipt" placeholder="Enter Working Hours : " name="whour" />
								<input type="text" required class="eipt" placeholder="Packet Money : " name="pmoney" />
								<select required name="esalary" class="eipt">
									<option class='elist'>Select The Salary</option>
									<option class='elist' value="0">Rs,0</option>
									<option class='elist' value="100">Rs,100</option>
									<option class='elist' value="200">Rs,200</option>
									<option class='elist' value="300">Rs,300</option>
									<option class='elist' value="400">Rs,400</option>
									<option class='elist' value="500">Rs,500</option>
									<option class='elist' value="500">Rs,600</option>
								</select>
								
								<input type="submit" name="asubmit" value="Save" class="eipt btns btn-danger"/><input type="reset" name="reset" value="Reset" class="eipt btns btn-danger"/>
							</form>
							
							<?php
								include "Attendancephp.php";
							?>
							<?php
								if(isset($_GET['mes']))
								{
									echo "<p class='succ'>Details Saved</p>";
								}
							?>
							</div>
							<div class="col-md-6">
								<div class="iptDiv">
									<center><img src="img/atts" class="addemp" /></center>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-12">
			<?php include "Footer.php"; ?>
		</div>
	</div>
</div>
</body>
</html>