						<table class="table tbe">
							<tr>
								<th class='theader'>S.No</th>
								<th class='theader'>Name</th>
								<th class='theader'>Fathername</th>
								<th class='theader'>Ph Number</th>
								<th class='theader'>Address</th>
								<th class='theader'>Day Salary</th>
								<th class='theader'>Photo</th>
								<th class='theader'>View</th>
								<th class='theader'>Delete</th>
							</tr>
							<?php
								
								$run="SELECT * FROM employees ";
								$tot=$conf->query($run);

								if($tot->num_rows>0)
								{
									$i=0;
									while($row=$tot->fetch_assoc())
									{
										$i++;
										echo "
										
											<tr>
												<td class='ttitle'>$i</td>
												<td class='ttitle'>{$row['NAME']}</td>
												<td class='ttitle'>{$row['FATHERNAME']}</td>
												<td class='ttitle'>{$row['PHONENUMBER']}</td>
												<td class='ttitle'>{$row['ADDRESS']}</td>
												<td class='ttitle'>{$row['DAYSALARY']}</td>
												<td class='ttitle'><img src='data:image;base64,{$row["PHOTO"]}' width='30px' height='30px'/></td>
												<td class='ttitle'><a href='View_Emp.php?id={$row["ID"]}'><img src='img/viewemp.jpg' width='30px' height='30px'></a></td>
												<td class='ttitle'><a href='delete.php?id={$row["ID"]}' class='btnr'><img src='img/del2.ico' width='30px' height='30px'></a></td>
											</tr>
											
										";
										
									}
									
								}
								
							?>
						</table>