
<?php
if(isset($_POST['wsubmit']))
	{
		$arun="INSERT INTO workdetails(CUSTOMER,WORKNAME,DATE,ADVANCEAMOUNT,BALANCEAMOUNT,PROJECTTOTALAMOUNT) VALUE('{$_POST['cname']}','{$_POST['wname']}','{$_POST['date']}','{$_POST['aamount']}','{$_POST['bamount']}','{$_POST['ptamount']}')";
								
			if($conf->query($arun))
			{ 
				echo "<script>window.open('workamountentry.php?mes=Details Saved','_self');</script>";
			}
			else
			{
				echo "Error";
			}
	}
?>