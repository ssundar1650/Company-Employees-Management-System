<?php
	include "conf.php";
	session_start();
	
	if(!isset($_SESSION['AID']))
	{
		echo "<script>window.open('index.php?mes=Please Login First','_self');</script>";
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Welcome To New Designers | Powered By : MSSoft1650</title>
	<link rel="stylesheet" href="mycss/style.css" />
	<link rel="stylesheet" href="mycss/style2.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link rel="stylesheet" href="mycss/loading.css" />
	<script src="js/jquery.js"></script>
	<script src="js/loading.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
	<style>
		.pagenum{
			padding:5px;
			margin-top:5px;
		}
		
	</style>
</head>
<body>
<div id="preloader">
	<div id="status">
	</div>
</div>
<div class="mainDivs">
	<div class="row">
		<div class="col-md-12">
			<?php include "Header.php"; ?>
		</div>
		<div class="col-md-3">
			<?php include "Sidemenu.php"; ?>
		</div>
		<div class="col-md-9">
			<div class="row">
				<div class="col-md-12">
					<div class="mainDiv">
						<div class="">
							<br>
							<h2 class="titletext text-center"><span>Total</span> Work</h2>	
						</div>
						<div class="table-responsive">
							<table class="table tbe">
							<tr>
								<th class='theader'>S.No</th>
								<th class='theader'>Work Name</th>
								<th class='theader'>Site Address</th>
								<th class='theader'>Property Owner</th>
								<th class='theader'>Contact No</th>
								<th class='theader'>Work Refer</th>
								<th class='theader'>Amount</th>
								<th class='theader'>View</th>
								<th class='theader'>Delete</th>
							</tr>
							<?php
								if(isset($_GET['page']))
								{
									$page=$_GET['page'];
								}
								else
								{
									$page=1;
								}
								if($page =="" || $page==1)
								{
									$page1=0;
								}
								else
								{
									$page1=($page*5)-5;
								}
								$run="SELECT * FROM worklist ORDER BY ID DESC LIMIT $page1,5";
								$tot=$conf->query($run);

								if($tot->num_rows>0)
								{
									$i=0;
									while($row=$tot->fetch_assoc())
									{
										$i++;
										echo "
										
											<tr>
												<td class='ttitle'>$i</td>
												<td class='ttitle'>{$row['WORKNAME']}</td>
												<td class='ttitle'>{$row['SITEADDRESS']}</td>
												<td class='ttitle'>{$row['CUSTOMERNAME']}</td>
												<td class='ttitle'>{$row['CONTACTNO']}</td>
												<td class='ttitle'>{$row['WORKREFER']}</td>
												<td class='ttitle'>{$row['PROJECTTOTALAMOUNT']}</td>
												<td class='ttitle'><a href='View_Work.php?id={$row["ID"]}'><img src='img/viewemp.jpg' width='30px' height='30px'></a></td>
												<td class='ttitle'><a href='Workdelete.php?id={$row["ID"]}' class='btnr'><img src='img/del2.ico' width='30px' height='30px'></a></td>
											</tr>
											
										";
										
									}
									
								}
								$run="SELECT * FROM worklist";
								$tot=$conf->query($run);
								$records = $tot->num_rows;
								$records_pages = $records/5;
								$records_pages= ceil($records_pages);
								
								
								if($records_pages >=2)
								{
									for($r=1;$r<=$records_pages;$r++)
									{
										echo '<a class="pagenum" href="?page='.$r.'">'.$r.'</a>';
									}
								}
								
							?>
						</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-12">
			<?php include "Footer.php"; ?>
		</div>
	</div>
</div>
</body>
</html>