<?php
	$conf=new mysqli("localhost","root","1650","newdesigners");
	
	if(!$conf)
	{
		echo "Database Not Connected";
	}
?>