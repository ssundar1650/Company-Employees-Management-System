<?php
	include 'conf.php';
	session_start();
	
	$del="DELETE FROM employees WHERE ID={$_GET['id']}";
	
	if($conf->query($del))
	{
		echo "<script>window.open('Total_emp.php?mes=Data Deleted','_self');</script>";
	}
	else
	{
		echo "<p class='error'>Data Deleted Processing Error</p>";
	}
?>