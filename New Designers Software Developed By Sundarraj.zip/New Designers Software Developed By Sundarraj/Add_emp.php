<?php
	include "conf.php";
	session_start();
	
	if(!isset($_SESSION['AID']))
	{
		echo "<script>window.open('index.php?mes=Please Login First','_self');</script>";
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Welcome To New Designers | Powered By : MSSoft1650</title>
	<link rel="stylesheet" href="mycss/style.css" />
	<link rel="stylesheet" href="mycss/style2.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link rel="stylesheet" href="mycss/loading.css" />
	<script src="js/jquery.js"></script>
	<script src="js/loading.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
	<style>
	</style>
</head>
<body>
<div id="preloader">
	<div id="status">
	</div>
</div>
<div class="mainDivs">
	<div class="row">
		<div class="col-md-12">
			<?php include "Header.php"; ?>
		</div>
		<div class="col-md-3">
			<?php include "Sidemenu.php"; ?>
		</div>
		<div class="col-md-9">
			<div class="row">
				<div class="col-md-12">
					<div class="mainDiv">
					
					<h2 class="titletext text-center"><span>Add</span> Employee</h2>
					<div class="row">
						<div class="col-md-6">
							<div class="iptDiv">
								<form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">
									<input required type="text" name="Ename" Placeholder="Employee Name : " class="eipt text-danger"/>
									<input required type="text" name="Efname" Placeholder="Employee Father Name : " class="eipt"/>
									<input required type="text" name="Enum" Placeholder="Phone Number : " class="eipt"/>
									<input required type="text" name="Eemail" Placeholder="Email Address : " class="eipt"/>
									<input required type="text" name="Eadd" Placeholder="Address : " class="eipt"/>
									<input required type="text" name="Esalary" Placeholder="Day Salary : " class="eipt"/>
									<input required type="file" name="Ephoto" class="eipt"/>
									<input type="submit" name="submit" value="Save" class="eipt btns btn-danger"/><input type="reset" name="reset" value="Reset" class="eipt btns btn-danger"/>
								</form>
								
								<?php 
									if(!empty($_POST['submit']))
									{
										if(getimagesize($_FILES['Ephoto']['tmp_name'])==false)
										{
											echo "<p class='error'>Please Select Image</p>";
										}
										else
										{
											$photo=$_FILES['Ephoto']['tmp_name'];
											$name=$_FILES['Ephoto']['name'];
											$photo=file_get_contents($photo);
											$photo=base64_encode($photo);
											
											$runs="INSERT INTO employees(NAME,FATHERNAME,PHONENUMBER,EMAIL,ADDRESS,DAYSALARY,PHOTO) VALUES('{$_POST['Ename']}','{$_POST['Efname']}','{$_POST['Enum']}','{$_POST['Eemail']}','{$_POST['Eadd']}','{$_POST['Esalary']}','$photo')";
											
											if($conf->query($runs))
											{
												echo "<p class='succ'>Details Saved</p>";
											}
											else
											{
												echo "<p class='error'>Details Not Saved</p>";
											}
										}
									}
								?>
							</div>
						</div>
						
						<div class="col-md-6">
							<div class="iptDiv">
								<center><img src="img/addemp.png" class="addemp" /></center>
							</div>
						</div>
					</div>
					</div>
					
				</div>
			</div>
		</div>
		<div class="col-md-12">
			<?php include "Footer.php"; ?>
		</div>
	</div>
</div>
</body>
</html>