
<?php
	if(isset($_POST['move']))
	{
		$setting="INSERT INTO totaldetails SELECT * FROM salary";
		
		if($conf->query($setting))
		{
			echo "<script>window.open('Settings.php?mes=Datails Moved','_self');</script>";
		}
		else
		{
			echo "error";
		}
	}
?>
