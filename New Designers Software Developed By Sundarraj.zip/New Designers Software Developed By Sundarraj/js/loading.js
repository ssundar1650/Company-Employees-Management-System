$(document).ready(function(){
			$(window).on('load',function(){
				$('#status').fadeOut();
				$('#preloader').delay(450).fadeOut('slow');
			})
		});