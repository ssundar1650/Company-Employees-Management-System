<!DOCTYPE html>
<html>
<head>
	<title>Welcome To New Designers | Powered By : MSSoft1650</title>
	<link rel="stylesheet" href="mycss/style.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
	<style>
		
	</style>
</head>
<body>
	<div class="HeaderDiv text-center">
		<div class="logoDiv">
			<h2><a href="index.php">New Designers</h2>
		</div>
		<div class="menuDiv">
			<ul>
				<li><a href="Attendance.php">Attendance</a>
				<li><a href="workamountentry.php">Work Amount Entry</a>
				<li><a href="Logout.php">Logout</a>
				<li><a href="Logout.php">Version : 1.0</a>
			</ul>
		</div>
	</div>
</body>
</html>