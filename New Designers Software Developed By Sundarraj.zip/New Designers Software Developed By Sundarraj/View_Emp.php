<?php
	include "conf.php";
	session_start();
	
	if(!isset($_SESSION['AID']))
	{
		echo "<script>window.open('index.php?mes=Please Login First','_self');</script>";
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Welcome To New Designers | Powered By : MSSoft1650</title>
	<link rel="stylesheet" href="mycss/style.css" />
	<link rel="stylesheet" href="mycss/style2.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link rel="stylesheet" href="mycss/loading.css" />
	<script src="js/jquery.js"></script>
	<script src="js/loading.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
	<style>
		.result{
			color:#F00000;
		}
		.vemp{
			margin:0px !important;
		}
	</style>
</head>
<body>
<div id="preloader">
	<div id="status">
	</div>
</div>
<div class="mainDivs">
	<div class="row">
		<div class="col-md-12">
			<?php include "Header.php"; ?>
		</div>
		<div class="col-md-3">
			<?php include "Sidemenu.php"; ?>
		</div>
		<div class="col-md-9">
			<div class="row">
				<div class="col-md-12">
					<div class="mainDiv">
						<?php
							$view="SELECT * FROM employees WHERE ID={$_GET['id']}";
							
							$emp=$conf->query($view);
							
							if($emp->num_rows>0)
							{
								$row=$emp->fetch_assoc();
								
							}
							else
							{
								echo "<p class='error'>Data Not Found</p>";
							}
						?>
						
						<div class="">
							<br>
							<h2 class="titletext text-center"><span>View</span> Mr. <?php echo $row['NAME']; ?> Details</h2>	
						</div>
						
						<div class="row">
							<div class="col-md-8">
							<div class="table-responsive">
								<table class="table tbe2">
									<tr>
										<td>
											<p class="vemp">Name : </p>
										<td>
										<td>
											<p class="vemp"><?php echo $row['NAME']; ?></p>
										<td>
									</tr>
									<tr>
										<td>
											<p class="vemp">Phone Number : </p>
										<td>
										<td>
											<p class="vemp"><?php echo $row['PHONENUMBER']; ?></p>
										<td>
									</tr>
									<tr>
										<td>
											<p class="vemp">Address : </p>
										<td>
										<td>
											<p class="vemp"><?php echo $row['ADDRESS']; ?></p>
										<td>
									</tr>
									<tr>
										<td>
											<p class="vemp">Total Working Dates : </p>
											<?php
												$salary="SELECT SUM( ATTENDANCE ) AS TOTAL FROM salary WHERE NAME = '{$row['NAME']}'";
												$tol=$conf->query($salary);
												$rw=mysqli_fetch_assoc($tol);
												$tolsalary=$rw['TOTAL']; 
											?>
										<td>
										<td>
											<p class="vemp"><?php echo "$tolsalary" ?></p>
										<td>
									</tr>
									<!--<tr>
										<td>
											<p class="vemp">Leave Dates : </p>
										<td>
										<td>
											<p class="vemp"><?php echo $row['ADDRESS']; ?></p>
										<td>
									</tr>-->
									<tr>
										<td>
											<p class="vemp">Total Packetmoney : </p>
											<?php
												$salary="SELECT SUM( PACKETMONEY ) AS TOTAL FROM salary WHERE NAME = '{$row['NAME']}'";
												$tol=$conf->query($salary);
												$rw=mysqli_fetch_assoc($tol);
												$tolpmoney=$rw['TOTAL']; 
											?>
										<td>
										<td>
											<p class="vemp"><?php echo "$tolpmoney" ?></p>
											
										<td>
									</tr>
									<tr>
										<td>
											<p class="vemp">Total Salary : </p>
											<?php
												$salary="SELECT SUM( SALARY ) AS TOTAL FROM salary WHERE NAME = '{$row['NAME']}'";
												$tol=$conf->query($salary);
												$rw=mysqli_fetch_assoc($tol);
												$tolsalarys=$rw['TOTAL']; 
											?>
										<td>
										<td>
											<p class="vemp"><?php echo "<span class=''>$tolsalarys</span>" ?></p>
											
										<td>
									</tr>
									<tr>
										<td>
											<p class="vemp"><span class='result'>Packetmoney - Salary : </span></p>
										<td>
										<td>
												
											<p class="vemp">
												<?php
													$t=$tolsalarys-$tolpmoney;
													echo "<span class='result'>Rs : $t</span>";
												?>
											</p>
										<td>
									</tr>
									
								</table>
							</div>
							</div>
							<div class="col-md-4">
								<div class="photoDiv">
									<?php echo "<img src='data:image;base64,{$row['PHOTO']}' align='right' width='150px' height='160px'/>"; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-12">
			<?php include "Footer.php"; ?>
		</div>
	</div>
</div>
</body>
</html>