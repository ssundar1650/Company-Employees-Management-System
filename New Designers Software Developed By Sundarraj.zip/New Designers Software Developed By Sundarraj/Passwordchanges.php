<?php
								if(isset($_POST['login']))
								{
									$pass="SELECT * FROM admin WHERE AEMAIL='{$_POST['Answer']}'";
								
									$run=$conf->query($pass);
									
									if($run->num_rows>0)
									{
										if($_POST['npass1']==$_POST['npass2'])
										{
											
											if($_POST['npass2'])
											{
												$sql="UPDATE admin SET APASSWORD='{$_POST['npass2']}' WHERE AEMAIL='{$_POST['Answer']}'";
											
												if($conf->query($sql))
												{
													echo "<script>window.open('Forgottenpassword.php?mess=Password Changed','_self')</script>";
												}
												else
												{
													echo "<script>window.open('Forgottenpassword.php?mess=Password Changes Error','_self')</script>";
												}
											}
											else
											{
												echo "<p class='err'>Please Enter Password Six Character Or Above</p>";
											}
										}
										else
										{
											echo "<script>alert('Password Not Matched');</script>";
										}
									}
									else
									{
										echo "";
									}
									
								}
							?>