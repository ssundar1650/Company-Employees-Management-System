<!DOCTYPE html>
<html>
<head>
	<title>Welcome To New Designers | Powered By : MSSoft1650</title>
	<link rel="stylesheet" href="mycss/style.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
	<style>
	.footerDiv{
		position:fixed;
		width:100%!important;
		background: #1488CC;  /* fallback for old browsers */
		color:white;
		height:60px;
	}
	.footerDiv a{
		text-align:center;
		line-height:60px;
		font-family: 'Poppins', sans-serif;
		color:white;
		text-decoration:none;
		font-weight:;
	}
	</style>
</head>
<body>
	<div class="footerDiv text-center">
		<center><a href="https://www.facebook.com/javacseofficial">Designed And Developed By : MSSoft1650</a></center>
	</div>
</body>
</html>