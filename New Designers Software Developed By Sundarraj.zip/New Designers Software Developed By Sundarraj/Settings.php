<?php
	include "conf.php";
	session_start();
	
	if(!isset($_SESSION['AID']))
	{
		echo "<script>window.open('index.php?mes=Please Login First','_self');</script>";
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Welcome To New Designers | Powered By : MSSoft1650</title>
	<link rel="stylesheet" href="mycss/style.css" />
	<link rel="stylesheet" href="mycss/style2.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link rel="stylesheet" href="mycss/loading.css" />
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
	
	<style>
	table tr td{
		border:0px solid black;
		font-family: 'Poppins', sans-serif;
		padding:10px;
		width:100%;
	}
	.btns{
		border:;
	}
	.passDiv{
		margin-top:10px;
	}
	.iptDiv{
		margin-top:100px;
	}
	</style>
</head>
<body>
<div id="preloader">
	<div id="status">
	</div>
</div>
<div class="mainDivs">
	<div class="row">
		<div class="col-md-12">
			<?php include "Header.php"; ?>
		</div>
		<div class="col-md-3">
			<?php include "Sidemenu.php"; ?>
		</div>
		<div class="col-md-9">
			<div class="row">
				<div class="col-md-12">
					<div class="mainDiv">
					<br>
					<h2 class="titletext text-center"><span>Settings</span> Page</h2>
					<div class="row">
						<div class="col-md-6">
							<div class="iptDiv">
							<h4 class="text-left">Table Changes</h4>
								<table class="settbe">
									<tr style="">
										<td>Move The Details To TotalDetails Table : </td>
										<td>
											<form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
												<input type="submit" class=" btn-danger" value="Move" name="move" />
											</form>
												<?php
													include "Movedetails.php";
												?>
										</td>
									</tr>
									<tr style="border:none!important;">
										<td>Reset The Salary Table : </td>
										<td>
											<form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
												<input type="submit" class=" btn-danger" value="Reset" name="reset" />
											</form>
												<?php
													include "Resettable.php";
												?>
												
										</td>
									</tr>
									<tr style="border:none!important;">
										<td>Reset The Salary Details Table : </td>
										<td>
											<form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
												<input type="submit" class=" btn-danger" value="Reset" name="reset1" />
											</form>
												<?php
													include "Resettotaldetailstable.php";
												?>
												
										</td>
									</tr>
								</table>
								<?php
									if(isset($_GET['mes']))
									{
										echo "<p class='succ'>Details Moved</p>";
									}
								?>
							</div>
						</div>
						
						<div class="col-md-6">
							<div class="iptDiv">
								
								
									<h4 class="text-left">Password Changes</h4>
									<form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
										<input required type="text" name="oldpass" Placeholder="Enter Old Password : " class="eipt text-danger"/>
										<input required type="text" name="newpass1" Placeholder="Enter New Password : " class="eipt text-danger"/>
										<input required type="text" name="newpass2" Placeholder="Enter Re-Enter New Password : " class="eipt text-danger"/>
										<input type="submit" name="resetpass" value="Save" class="eipt btns btn-danger"/><input type="reset" name="reset" value="Reset" class="eipt btns btn-danger"/>
									</form>
									
								
							</div>
									<?php
										include "resetpassword.php";
									?>
									<?php
									if(isset($_GET['mess']))
									{
										echo "<p class='succ'>Password Changed</p>";
									}
									?>
						</div>
					</div>
					</div>
					
				</div>
			</div>
		</div>
		<div class="col-md-12">
			<?php include "Footer.php"; ?>
		</div>
	</div>
</div>
<script src="js/jquery.js"></script>
<script src="js/loading.js"></script>
</body>
</html>