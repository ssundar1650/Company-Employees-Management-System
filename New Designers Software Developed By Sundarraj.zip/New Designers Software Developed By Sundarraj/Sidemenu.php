<!DOCTYPE html>
<html>
<head>
	<title>Welcome To New Designers | Powered By : MSSoft1650</title>
	<link rel="stylesheet" href="mycss/style.css" />
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
</head>
<body>
	<div class="sidemenu">
		<ul>
			<li><a href="Dashboard.php">Home</a></li>
			<li><a href="Add_emp.php">New Employee</a></li>
			<li><a href="Total_emp.php">Employee List</a></li>
			<li><a href="New_Work.php">New Work</a></li>
			<li><a href="Total_work.php">Work List</a></li>
			<li><a href="Salary.php">Salary Details</a></li>
			<li><a href="Settings.php">Settings</a></li>
			<li><a href="Logout.php">Log Out</a></li>
		</ul>
	</div>
</body>
</html>