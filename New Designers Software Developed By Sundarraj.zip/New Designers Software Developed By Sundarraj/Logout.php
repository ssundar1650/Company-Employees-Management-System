<?php
	include "conf.php";
	
	session_start();
	
	session_destroy();
	
	echo "<script>window.open('index.php?mes=Logout Successfully','_self');</script>";
?>