<?php
	include 'conf.php';
	session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Welcome To New Designers | Powered By : MSSoft1650</title>
	<link rel="stylesheet" href="css/bootstrap.min.css" />
	<link rel="stylesheet" href="mycss/loging.css" />
	<link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
	<link rel="stylesheet" href="mycss/loading.css" />
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="js/bootstrap.min.js" />
	<script src="js/jquery.js"></script>
	<script src="js/loading.js"></script>
	
	<style>
	body{
		height:100vh;
		width:100%;
		background-image:url('img/loginimg.png');
		background-size:cover;
		background-repeat:no-repeat;
		overflow-x:hidden;
	}
	.inDiv1{
		padding:80px;
		margin-top:;
	}
	.inDiv3{
		padding:0px 80px;
	}
	.inDiv2{
		padding-top:130px;
		margin:0px 80px;
	}
	.slidebox{
		width:400px;
		height:400px;
		margin:0px;
	}
	.ipbox{
		width:100%;
		margin:15px auto;
		padding:10px;
		<!--margin-bottom:10px;-->
	}
	.btns{
		width:49.1%;
		padding:10px;
		border:none;
		font-family: 'Poppins', sans-serif;
	}
	input[type=text]
	{
		font-family: 'Poppins', sans-serif;
		color:#F00000;
	}
	p a{
		color:white;
		font-family: 'Poppins', sans-serif;
	}
	p a:hover{
		color:#F00000;
		text-decoration:none!important;
	}
	.ttext{
		padding-top:120px;
	}
	</style>
</head>
<body>
<div id="preloader">
	<div id="status">
	</div>
</div>
<div class="col-md-12">
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h2 class="ttext text-center text-white">Password Reset</h2>
				<div class="inDiv inDiv3">
					<h5 class="text-center text-white">Enter Correct Answer</h5>
					<form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
						<input type="text" name="Answer" required placeholder="Enter Your Email Address : " class="ipbox" />
						<input type="text" name="npass1" required placeholder="Enter New Password : " class="ipbox" />
						<input type="text" name="npass2" required placeholder="Re-Enter New Password : " class="ipbox" />
						<input type="submit" name="login" value="Log In" class="btns btn-primary">
						<input type="reset" name="reset" value="Cancel" class="btns btn-danger">
					</form>
					<?php
						include "Passwordchanges.php";
					?>
					<br>
					<p class="text-center"><a href="index.php">Go To Home</a></p>
					
				</div>
			</div>
			<div class="col-md-6">
				<div class="inDiv inDiv2">
					<div class="projectSlide">
					<div class="owl-carousel sliderWrapper owl-theme">
							<div class="item slidebox"><img src="img/slide0.png"></div>
							<div class="item slidebox"><img src="img/slide1.png"></div>
							<div class="item slidebox"><img src="img/slide2.png"></div>
							<div class="item slidebox"><img src="img/slide3.png"></div>
					</div>		
				</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
<script src="js/jquery.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/slider.js"></script>
</body>
</html>